enum DegreeType {SECURITY, NETWORK, SOFTWARE};

static const std::string degreeTypeStrings[] = { "SECURITY","NETWORK","SOFTWARE"};
